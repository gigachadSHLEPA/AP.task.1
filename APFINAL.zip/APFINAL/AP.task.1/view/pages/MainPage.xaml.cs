﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AP.task._1.view.pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();

        }
        private void MNBTN1_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP());
        }
        private void MNBTN2_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP1());
        }
        private void MNBTN3_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP2());
        }
        private void MNBTN4_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP3());
        }
        private void MNBTN5_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP4());
        }
        private void MNBTN6_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP5());
        }
        private void MNBTN7_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP6());
        }
        private void MNBTN8_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP7());
        }
        private void MNBTN9_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP8());
        }
        private void MNBTN10_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP9());
        }
        private void MNBTN11_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP10());
        }
        private void MNBTN12_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP11());
        }
        private void MNBTN13_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP12());
        }
        private void MNBTN14_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP13());
        }
        private void MNBTN15_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP14());
        }
        private void MNBTN16_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP15());
        }
        private void MNBTN17_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP16());
        }
        private void MNBTN18_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP17());
        }
        private void MNBTN19_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP18());
        }
        private void MNBTN20_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP19());
        }
        private void MNBTN21_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP20());
        }
        private void MNBTN22_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP());
        }
        private void MNBTN23_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP());
        }
        private void MNBTN24_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP());
        }
        private void MNBTN25_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP());
        }
        private void MNBTN26_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP());
        }
        private void MNBTN27_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP());
        }
        private void MNBTN28_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP());
        }
        private void MNBTN29_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP());
        }
        private void MNBTN30_Click(object sender, RoutedEventArgs e)
        {
            Coreee.MyCore?.Navigate(new AP());
        }

    }
}
