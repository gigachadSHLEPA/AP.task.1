﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace AP.task._1
{
    internal class Coreee
    {
        public static Frame? MyCore { get; set; }
    }
}
